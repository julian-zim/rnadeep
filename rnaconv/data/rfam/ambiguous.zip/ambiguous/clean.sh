#!/usr/bin/bash

rm -r ./seed_trees/
rm -r ./seed_alignments/
rm -r ./seed_neighbourhoods/
rm -r ./seed_frequencies/
rm ./filter_o.txt
