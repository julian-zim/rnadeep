#!/usr/bin/bash

python ../copy.py ../full ./ $(python get_filenames.py)
