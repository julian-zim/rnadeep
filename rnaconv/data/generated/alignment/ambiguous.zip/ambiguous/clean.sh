rm -r ./alignments/
rm -r ./neighbourhoods/
rm -r ./frequencies/
rm ./generate_o.txt
rm ./filter_o.txt
